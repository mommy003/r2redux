
  r2_enrich = function (dat,v1,v2,nv,exp1) {
    source("aoa12_1.r")
    source("aoa12_13.r")
    source("aoa1_2.r")
    source("aoa12_3.r")
    source("aoa12_34.r")

    dat=scale(dat);omat=cor(dat)

      m1=lm(dat[,1]~dat[,(1+v1)])
      s1=summary(m1)
      m2=lm(dat[,1]~dat[,(1+v2)])
      s2=summary(m2)
      m3=lm(dat[,1]~dat[,1+v1]+dat[,1+v2])
      s3=summary(m3)

      R2=s1$r.squared;mv2=1    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100  #*(1-R2)

      R2=s2$r.squared;mv2=1    #expected variance for s1r2
      t200=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t200           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t200=t200^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t200  #*(1-R2)

      R2=s3$r.squared;mv2=3    #expected variance for s1r2
      t300=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t300           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t300=t300^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var12=t300  #*(1-R2)

      dvr1=s3$r.squared-s1$r.squared
      chi_dum=dvr1/(1/(nv-1)*(1-dvr1)^2) #NCP
      p1=pchisq(chi_dum,1,lower.tail=F)

      dvr2=s3$r.squared-s2$r.squared
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      ord=c(1,(1+v1),(1+v2))
      #omat=omat[ord,ord]
      aoa1=olkin12_1(omat[ord,ord],nv)
      aoa0=olkin1_2(omat[ord,ord],nv)

      ord=c(1,(1+v2),(1+v1))
      #omat=omat[ord,ord]
      aoa2=olkin12_1(omat[ord,ord],nv)

      # cov (s3r2-s1r2,s3r2-s2r2) ***********************************************
      # for mean(res[,3]*res[,3])
      v300=s3$r.squared^2+t300
      # for mean(res[,2]*res[,1])=mean()*mean()+cov(1,2)
      v300=v300+s2$r.squared*s1$r.squared+(t100+t200-aoa0)/2
      #for mean(res[,3]*res[,2])
      v300=v300-(s3$r.squared*s2$r.squared+(t300+t200-aoa2)/2)
      #for mean(res[,3]*res[,1])
      v300=v300-(s3$r.squared*s1$r.squared+(t300+t100-aoa1)/2)

      v102=dvr2*dvr1
      cov=v300-v102

      #enrichment p-value
      dvrt=dvr1+dvr2; ratio1=dvr1/dvrt; ratio2=dvr2/dvrt

      vart=aoa1+aoa2+2*cov
      covt1=aoa1+cov
      covt2=aoa2+cov

      ratio1_var=(ratio1^2)*(aoa1/dvr1^2+vart/dvrt^2-2*covt1/(dvr1*dvrt))
      ratio2_var=(ratio2^2)*(aoa2/dvr2^2+vart/dvrt^2-2*covt2/(dvr2*dvrt))

      chisq2=((ratio2-exp1)^2)/ratio2_var
      p3=pchisq(chisq2,1,lower.tail=F)

      #95% CI
      uci=ratio2+1.96*ratio2_var^.5
      lci=ratio2-1.96*ratio2_var^.5

      #z=list(var1=var1,var2=var2,var12=var12,mean_diff12_1=dvr1,mean_diff12_2=dvr2,var_diff1_2=aoa0,var_diff12_1=aoa1,var_diff12_2=aoa2,cov=cov,ratio1=ratio1,ratio2=ratio2,ratio1_var=ratio1_var,ratio2_var=ratio2_var,enrich_p=p3,upper_ratio1=uci,lower_ratio1=lci)
      z=list(var1=var1,var2=var2,var12=var12,mean_diff12_1=dvr1,mean_diff12_2=dvr2,var_diff1_2=aoa0,var_diff12_1=aoa1,var_diff12_2=aoa2,cov=cov,ratio=ratio2,ratio_var=ratio2_var,enrich_p=p3,upper_ratio=uci,lower_ratio=lci)
      return(z)


  }



