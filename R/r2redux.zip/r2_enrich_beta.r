
  r2_enrich_beta = function (dat,v1,v2,nv,exp1) {
    #source("aoa12_1.r")
    #source("aoa12_13.r")
    #source("aoa1_2.r")
    #source("aoa12_3.r")
    #source("aoa12_34.r")
    source("aoa_beta1_2.r")

    dat=scale(dat);omat=cor(dat)

      m1=lm(dat[,1]~dat[,(1+v1)])
      s1=summary(m1)
      m2=lm(dat[,1]~dat[,(1+v2)])
      s2=summary(m2)
      m3=lm(dat[,1]~dat[,1+v1]+dat[,1+v2])
      s3=summary(m3)

      ord=c(1,(1+v1),(1+v2))
      aoa=olkin_beta1_2(omat[ord,ord],nv)
      var1=aoa$var1
      var2=aoa$var2
      var1_2=aoa$var1_2

      cov=-0.5*(var1_2-var1-var2)

      dvr1=s3$coefficients[2,1]^2
      dvr2=s3$coefficients[3,1]^2
      #dvr1=s3$coefficients[2,1]
      #dvr2=s3$coefficients[3,1]

      #enrichment p-value
      dvrt=dvr1+dvr2; ratio1=dvr1/dvrt; ratio2=dvr2/dvrt

      vart=var1+var2+2*cov
      covt1=var1+cov
      covt2=var2+cov

      ratio1_var=(ratio1^2)*(var1/dvr1^2+vart/dvrt^2-2*covt1/(dvr1*dvrt))
      ratio2_var=(ratio2^2)*(var2/dvr2^2+vart/dvrt^2-2*covt2/(dvr2*dvrt))

      chisq1=((ratio1-exp1)^2)/ratio1_var
      p3=pchisq(chisq1,1,lower.tail=F)

      #95% CI
      uci=ratio1+1.96*ratio1_var^.5
      lci=ratio1-1.96*ratio1_var^.5

      #z=list(var1=var1,var2=var2,var1_2=var1_2,beta1_sq=dvr1,beta2_sq=dvr2,cov=cov,ratio1=ratio1,ratio2=ratio2,ratio1_var=ratio1_var,ratio2_var=ratio2_var,enrich_p=p3,upper_ratio1=uci,lower_ratio1=lci)
      z=list(var1=var1,var2=var2,var1_2=var1_2,beta1_sq=dvr1,beta2_sq=dvr2,cov=cov,ratio=ratio1,ratio_var=ratio1_var,enrich_p=p3,upper_ratio=uci,lower_ratio=lci)
      return(z)


  }



