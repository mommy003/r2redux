  #' r2_diff function
  #'
  #' This function estimate var(R2(y~x\[,v1]) - R2(y~x\[,v2]))
  #' where R2 is the R squared value of the model,
  #' y is N x 1 depedent variable
  #' x is N x M explanatory variables
  #' @param dat N x (M+1) matrix having variables in the order of (y,x)
  #' @param v1 This can be set as v1=c(1) or v1=c(1,2)
  #' @param v2 This can be set as v2=c(2), v2=c(3), v2=c(1,3) or v2=c(3,4)
  #' @param nv sampel size
  #' @keywords R2 variance information matrix
  #' @export
  #' @examples
  #' r2_diff(dat,v1,v2,nv) (see example file)

  r2_diff = function (dat,v1,v2,nv) {
    source("aoa12_1.r")
    source("aoa12_13.r")
    source("aoa1_2.r")
    source("aoa12_3.r")
    source("aoa12_34.r")

    dat=scale(dat);omat=cor(dat)

    if (length(v1)==1 & length(v2)==1) {
      ord=c(1,(1+v1),(1+v2))
      #omat=omat[ord,ord]

      m1=lm(dat[,1]~dat[,(1+v1)])
      s1=summary(m1)

      m2=lm(dat[,1]~dat[,(1+v2)])
      s2=summary(m2)

      R2=s1$r.squared;mv2=1    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100 #*(1-R2)

      R2=s2$r.squared;mv2=1    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t100   #*(1-R2)

      LR=-2*(logLik(m2)-logLik(m1))
      p1=pchisq(LR,1,lower.tail=F)

      dvr2=s1$r.squared-s2$r.squared
      dvr=(s1$r.squared^.5-s2$r.squared^.5)^2
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      aoa=olkin1_2(omat[ord,ord],nv)
      chi_dum=dvr2^2/aoa
      p3=pchisq(chi_dum,1,lower.tail=F)

      uci=dvr2+1.96*aoa^.5
      lci=dvr2-1.96*aoa^.5

      z=list(var1=var1,var2=var2,var_diff=aoa,LRT_p=p1,p2=p2,r2_based_p=p3,mean_diff=dvr2,upper_diff=uci,lower_diff=lci)
      #NOTE: r2_based_p=p3 due to normal distribution
      return(z)
    }

    if (length(v1)==2 & length(v2)==1 & length(unique(c(v1,v2)))==2) {
      if (v1[1]==v2[1]) {ord=c(1,(1+v1[1]),(1+v1[2]))}
      if (v1[2]==v2[1]) {ord=c(1,(1+v1[2]),(1+v1[1]))}
      #omat=omat[ord,ord]

      m1=lm(dat[,1]~dat[,1+v1[1]]+dat[,1+v1[2]])
      s1=summary(m1)

      m2=lm(dat[,1]~dat[,(1+v2)])
      s2=summary(m2)

      R2=s1$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100  #*(1-R2)

      R2=s2$r.squared;mv2=1    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t100   #*(1-R2)

      LR=-2*(logLik(m2)-logLik(m1))
      p1=pchisq(LR,1,lower.tail=F)

      dvr=(s1$r.squared^.5-s2$r.squared^.5)^2
      dvr2=s1$r.squared-s2$r.squared
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      aoa=olkin12_1(omat[ord,ord],nv)
      chi_dum2=dvr2^2/aoa
      p3=pchisq(chi_dum2,1,lower.tail=F)

      #95% CI
      mv=1;lamda=chi_dum
      uci=qchisq(0.975,1,ncp=lamda)
      uci=(uci-lamda-mv)/(2*(mv+2*lamda))^.5
      uci=uci*aoa^.5+dvr2
      lci=qchisq(0.025,1,ncp=lamda)
      lci=(lci-lamda-mv)/(2*(mv+2*lamda))^.5
      lci=lci*aoa^.5+dvr2

      z=list(var1=var1,var2=var2,var_diff=aoa,LRT_p=p1,p3=p3,r2_based_p=p2,mean_diff=dvr2,upper_diff=uci,lower_diff=lci)
      #NOTE: r2_based_p=p2 due to chi^2 distribution
      return(z)
    }

    if (length(v1)==2 & length(v2)==1 & length(unique(c(v1,v2)))==3) {
      ord=c(1,(1+v1[1]),(1+v1[2]),(1+v2[1]))
      #omat=omat[ord,ord]

      m1=lm(dat[,1]~dat[,1+v1[1]]+dat[,1+v1[2]])
      s1=summary(m1)

      m2=lm(dat[,1]~dat[,(1+v2)])
      s2=summary(m2)

      R2=s1$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100  #*(1-R2)

      R2=s2$r.squared;mv2=1    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t100  #*(1-R2)

      LR=-2*(logLik(m2)-logLik(m1))
      p1=pchisq(LR,1,lower.tail=F)

      dvr=(s1$r.squared^.5-s2$r.squared^.5)^2
      dvr2=s1$r.squared-s2$r.squared
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      aoa=olkin12_3(omat[ord,ord],nv)    #check
      chi_dum2=dvr2^2/aoa
      p3=pchisq(chi_dum2,1,lower.tail=F)

      #95% CI
      uci=dvr2+1.96*aoa^.5
      lci=dvr2-1.96*aoa^.5

      z=list(var1=var1,var2=var2,var_diff=aoa,LRT_p=p1,p2=p2,r2_based_p=p3,mean_diff=dvr2,upper_diff=uci,lower_diff=lci)
      #NOTE: r2_based_p=p3 due to normal distribution
      return(z)
    }


    if (length(v1)==2 & length(v2)==2 & length(unique(c(v1,v2)))==3) {
      if (v1[1]==v2[1]) {ord=c(1,(1+v1[1]),(1+v1[2]),(1+v2[2]))}
      if (v1[1]==v2[2]) {ord=c(1,(1+v1[1]),(1+v1[2]),(1+v2[1]))}
      if (v1[2]==v2[1]) {ord=c(1,(1+v1[2]),(1+v1[1]),(1+v2[2]))}
      if (v1[2]==v2[2]) {ord=c(1,(1+v1[2]),(1+v1[1]),(1+v2[1]))}
      #omat=omat[ord,ord]

      m1=lm(dat[,1]~dat[,1+v1[1]]+dat[,1+v1[2]])
      s1=summary(m1)

      m2=lm(dat[,1]~dat[,1+v2[1]]+dat[,1+v2[2]])
      s2=summary(m2)

      R2=s1$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100  #*(1-R2)

      R2=s2$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t100  #*(1-R2)

      LR=-2*(logLik(m2)-logLik(m1))
      p1=pchisq(LR,1,lower.tail=F)

      dvr=(s1$r.squared^.5-s2$r.squared^.5)^2
      dvr2=s1$r.squared-s2$r.squared
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      aoa=olkin12_13(omat[ord,ord],nv)
      chi_dum2=dvr2^2/aoa
      p3=pchisq(chi_dum2,1,lower.tail=F)

      #95% CI
      uci=dvr2+1.96*aoa^.5
      lci=dvr2-1.96*aoa^.5

      z=list(var1=var1,var2=var2,var_diff=aoa,LRT_p=p1,p2=p2,r2_based_p=p3,mean_diff=dvr2,upper_diff=uci,lower_diff=lci)
      #NOTE: r2_based_p=p3 due to normal distribution
      return(z)
    }

    if (length(v1)==2 & length(v2)==2 & length(unique(c(v1,v2)))==4) {
      ord=c(1,(1+v1[1]),(1+v1[2]),(1+v2[1]),(1+v2[2]))
      #omat=omat[ord,ord]

      m1=lm(dat[,1]~dat[,1+v1[1]]+dat[,1+v1[2]])
      s1=summary(m1)

      m2=lm(dat[,1]~dat[,1+v2[1]]+dat[,1+v2[2]])
      s2=summary(m2)

      R2=s1$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var1=t100  #*(1-R2)

      R2=s2$r.squared;mv2=2    #expected variance for s1r2
      t100=(1/(nv-1) *(1-R2)^2) #Infor matrix
      lamda=R2/t100           #non-central chi^2 (mu=k+lamda, var=2*(k+2*lamda))
      t100=t100^2*2*(mv2+2*lamda)  #var(beta)^2*var(non-cental chi)
      var2=t100  #*(1-R2)

      LR=-2*(logLik(m2)-logLik(m1))
      p1=pchisq(LR,1,lower.tail=F)

      dvr=(s1$r.squared^.5-s2$r.squared^.5)^2
      dvr2=s1$r.squared-s2$r.squared
      chi_dum=dvr2/(1/(nv-1)*(1-dvr2)^2) #NCP
      p2=pchisq(chi_dum,1,lower.tail=F)

      aoa=olkin12_34(omat[ord,ord],nv)
      chi_dum2=dvr2^2/aoa
      p3=pchisq(chi_dum2,1,lower.tail=F)

      #95% CI
      uci=dvr2+1.96*aoa^.5
      lci=dvr2-1.96*aoa^.5

      z=list(var1=var1,var2=var2,var_diff=aoa,LRT_p=p1,p2=p2,r2_based_p=p3,mean_diff=dvr2,upper_diff=uci,lower_diff=lci)
      #NOTE: r2_based_p=p3 due to normal distribution
      return(z)
    }



  }


